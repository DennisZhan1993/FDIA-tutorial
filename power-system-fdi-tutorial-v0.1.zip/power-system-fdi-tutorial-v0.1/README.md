# Power-System FDI Tutorial

A small, transparent Python teaching repository for graduate students learning
**power-system state estimation, false-data injection (FDI), and residual-based
bad-data detection**.

> **Scope:** synthetic, offline 3-bus experiments only. This repository is for
> classroom learning and defensive research.

---

## Learning goals

After completing V0.1, students should be able to explain and reproduce:

1. the DC measurement model \(z=Hx+e\);
2. weighted least-squares (WLS) state estimation;
3. residual-based bad-data detection;
4. a simple single-measurement perturbation;
5. the classical model-consistent construction \(a=Hc\);
6. why the latter can preserve the WLS residual in the ideal linear model.

---

## Repository structure

```text
power-system-fdi-tutorial/
├── README.md
├── requirements.txt
├── notebooks/
│   ├── 01_dc_state_estimation.ipynb
│   ├── 02_naive_fdi_attack.ipynb
│   ├── 03_stealthy_fdi_attack.ipynb
│   └── 04_bad_data_detection.ipynb
├── src/
│   ├── grid_model.py
│   ├── state_estimator.py
│   ├── attack_generator.py
│   ├── metrics.py
│   └── demo.py
├── tests/
├── docs/
├── figures/
└── data/generated/
```

---

## 1. Install

Create a virtual environment if desired, then run

```bash
pip install -r requirements.txt
```

Launch Jupyter:

```bash
jupyter notebook
```

---

## 2. Run the command-line demo

From the project root:

```bash
python -m src.demo
```

---

## 3. Teaching model

The state is

\[
x=
\begin{bmatrix}
\theta_2\\
\theta_3
\end{bmatrix},
\qquad
\theta_1=0.
\]

The measurement vector is

\[
z=
\begin{bmatrix}
P_{12}\\
P_{13}\\
P_{23}\\
P_2\\
P_3
\end{bmatrix},
\]

and the measurement model is

\[
z=Hx+e.
\]

For line susceptances \(b_{12}=10\), \(b_{13}=5\), and \(b_{23}=8\),

\[
H=
\begin{bmatrix}
-10 & 0\\
0 & -5\\
8 & -8\\
18 & -8\\
-8 & 13
\end{bmatrix}.
\]

---

## 4. Recommended notebook order

### Notebook 01 — DC state estimation

Learn \(z=Hx+e\), WLS, residuals, and numerical state recovery.

### Notebook 02 — Naive FDI

Perturb one measurement and observe the change in the residual statistic.

### Notebook 03 — Model-consistent FDI

Construct

\[
a=Hc
\]

and verify numerically that the estimated state changes while the ideal linear
WLS residual is preserved.

### Notebook 04 — Bad-data detection

Introduce the chi-square threshold and compare normal, naive-attack, and
model-consistent-attack cases.

---

## 5. Run tests

```bash
pytest -q
```

Expected result:

```text
2 passed
```

---

## Suggested classroom workflow

A useful 90-minute teaching sequence is:

- 20 min: derive the 3-bus matrix \(H\);
- 20 min: implement WLS;
- 15 min: inject a naive perturbation;
- 20 min: construct \(a=Hc\);
- 15 min: discuss why residual-only detection can fail.

---

## Next versions

Planned teaching extensions:

- V0.2: Monte Carlo detection probability and false alarm rate;
- V0.3: Isolation Forest / Random Forest baselines;
- V0.4: IEEE-14 and pandapower benchmark;
- V1.0: complete graduate-level teaching package.

---

## Academic-use note

Please cite the original literature on false-data injection attacks when using
this repository in course notes, papers, or presentations. A references section
will be expanded in later versions.
